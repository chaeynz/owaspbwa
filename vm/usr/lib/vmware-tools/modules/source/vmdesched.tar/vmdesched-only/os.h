/* **********************************************************
 * Copyright 2004 VMware, Inc.  All rights reserved.
 * **********************************************************/

/*
 * os.h --
 *
 *      Definitions for OS-specific wrapper functions required
 *      by "vmdesched".  This allows customers to build their own
 *      vmdesched driver for custom versioned kernels without the
 *      need for source code.
 */

#ifndef _OS_H
#define _OS_H

#ifdef __x86_64__
# define CDECL
#else
# define CDECL __attribute__((cdecl, regparm(0)))
#endif

/*
 * Types
 */
typedef void CDECL (*os_timer_callback)(void*);
typedef int  CDECL (*os_thread_function)(void*);
typedef int  CDECL (*os_simple_proc_read_callback)(char*);

typedef struct vmdesched_os_data_t vmdesched_os_data;

/*
 * Functions
 */
extern void CDECL os_add_timer_callback(os_timer_callback callback,
					void *param);
extern void CDECL os_init_timer(void);
extern void CDECL os_del_timer_sync(void);

extern unsigned int CDECL os_smp_num_cpus(void);
extern unsigned int CDECL os_smp_current_cpuid(void);

extern int CDECL os_vsprintf(char *str, const char *format, ...);
extern int CDECL os_printk(const char *format, ...);

extern vmdesched_os_data* CDECL os_init_private_data(int ncpus);

extern void  CDECL os_spin_lock(vmdesched_os_data *osdata);
extern void  CDECL os_spin_unlock(vmdesched_os_data *osdata);

extern void CDECL os_wake_up_interruptible(vmdesched_os_data *osdata, int id);
extern void CDECL os_wait_event_interruptible(vmdesched_os_data *osdata, int id);

extern int CDECL os_signal_pending_current(void);

extern int CDECL os_register_chrdev(unsigned int major, const char *name);
extern int CDECL os_unregister_chrdev(unsigned int major, const char *name);

extern void CDECL os_create_simple_proc_read_node(char *procNodeName,
						  os_simple_proc_read_callback func);
extern void CDECL os_remove_simple_proc_node(char *procNodeName);

#endif  /* OS_H */
