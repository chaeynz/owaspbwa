/* **********************************************************
 * Copyright (C) 2005 VMware, Inc.  All Rights Reserved. -- VMware Confidential
 * **********************************************************/

/*
 * set_user_nice appeared in 2.4.21.  But some distros
 * backported it to older kernels.
 */
#include <linux/autoconf.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 4, 21)
#include <linux/sched.h>

void test(void) {
   set_user_nice(current, -20);
}
#endif
