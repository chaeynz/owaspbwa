/* **********************************************************
 * Copyright (C) 2004 VMware, Inc.  All Rights Reserved. -- VMware Confidential
 * **********************************************************/

/*
 * Detect whether we have 'struct poll_wqueues'
 * 2.6.x kernels always had this struct.  Stock 2.4.x kernels
 * never had it, but some distros backported epoll patch.
 */

#include <linux/autoconf.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
#include <linux/poll.h>

void poll_test(void) {
        struct poll_wqueues test;

        return poll_initwait(&test);
}
#endif
