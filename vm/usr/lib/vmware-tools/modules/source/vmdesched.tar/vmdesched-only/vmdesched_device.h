/* **********************************************************
 * Copyright (C) 2004 VMware, Inc.
 * All Rights Reserved
 * **********************************************************/

/*
 * vmdesched_device.h --
 *
 *     Definition for device-specific constants required by
 *     vmdesched device. This may be os-specific, and thus is only
 *     included in os.c and service file.
 */

#ifndef VMDESCHED_DEVICE_H
#define VMDESCHED_DEVICE_H

#include <linux/ioctl.h>

#define VMDESCHED_DEVICE_PATH "/dev/vmdesched"

#define VMDESCHED_IOC_MAGIC 0xFF
#define VMDESCHED_IOC_STARTPOLL _IO(VMDESCHED_IOC_MAGIC, 0)
#define VMDESCHED_IOC_CONSUME _IO(VMDESCHED_IOC_MAGIC,1)
#define VMDESCHED_IOC_STOPPOLL _IO(VMDESCHED_IOC_MAGIC,2)
#define VMDESCHED_IOC_MAXNR 3

#endif
