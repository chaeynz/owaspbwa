/* ************************************************************************
 * Copyright 2007 VMware, Inc.  All rights reserved. -- VMware Confidential
 * ************************************************************************/

/*
 * vmdesched_version.h --
 *
 * Version definitions for the Linux vmdesched driver.
 */

#ifndef _VMDESCHED_VERSION_H_
#define _VMDESCHED_VERSION_H_

#define VMDESCHED_DRIVER_VERSION          1.0.0.0
#define VMDESCHED_DRIVER_VERSION_COMMAS   1,0,0,0
#define VMDESCHED_DRIVER_VERSION_STRING   "1.0.0.0"

#endif /* _VMDESCHED_VERSION_H_ */
