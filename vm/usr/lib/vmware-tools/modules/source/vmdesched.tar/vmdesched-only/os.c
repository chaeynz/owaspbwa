/* **********************************************************
 * Copyright (C) 2004 VMware, Inc. All rights reserved.
 * -- VMware Confidential
 * **********************************************************/

/*
 * os.c --
 *
 *      Wrappers for Linux system functions required by "vmdesched".
 *      This allows customers to build their own vmmemctl driver for
 *      custom versioned kernels without the need for source code.
 *
 *      Linux 2.4.x and 2.6.x kernels are supported. However, currently
 *      we will only support UP mode.
 *
 */

#include "driver-config.h"

#include "compat_completion.h"
#include "compat_fs.h"
#include "compat_ioport.h"
#include "compat_kernel.h"
#include "compat_module.h"
#include "compat_sched.h"
#include "compat_spinlock.h"
#include "compat_uaccess.h"
#include "compat_version.h"
#include "compat_wait.h"

#include <linux/errno.h>
#include <linux/ioctl.h>
#include <linux/proc_fs.h>
#include <linux/smp_lock.h>
#include <stdarg.h>


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0)
#error vmdesched module does not support 2.2.x kernels
#endif


#include "os.h"
#include "vmdesched_def.h"
#include "vmdesched_core.h"
#include "vmdesched_device.h"
#include "vmdesched_version.h"


/*
 * Types
 */

/* Vmdesched device os-specific data structure */
struct vmdesched_os_data_t {
   spinlock_t spinlock;
   wait_queue_head_t waitqueue[VMDESCHED_MAX_CPUS];
   int wake[VMDESCHED_MAX_CPUS];
};


static int vmdesched_ioctl(struct inode *inode, struct file *file,
                           unsigned int cmd, unsigned long arg);
#if defined(HAVE_UNLOCKED_IOCTL) || defined(HAVE_COMPAT_IOCTL)
static long vmdesched_unlocked_ioctl(struct file *file,
                                     unsigned int cmd, unsigned long arg);
#endif
static int vmdesched_open(struct inode *inode, struct file *file);
static int vmdesched_release(struct inode *inode, struct file *file);

/*
 * File operations for vmdesched driver.
 */
static struct file_operations vmdesched_fops ={
   .owner = THIS_MODULE,
#ifdef HAVE_UNLOCKED_IOCTL
   .unlocked_ioctl = vmdesched_unlocked_ioctl,
#else
   .ioctl = vmdesched_ioctl,
#endif
#ifdef HAVE_COMPAT_IOCTL
   .compat_ioctl = vmdesched_unlocked_ioctl,
#endif
   .open = vmdesched_open,
   .release = vmdesched_release,
};

static struct vmdesched_os_data_t vmdeschedOsData;
static struct timer_list globalTimer;

/*
 * Backward compatibility for cpus_weight...
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 0)
#include <linux/bitops.h>


/*
 *----------------------------------------------------------------------------
 *
 * vm_hweight --
 *
 *      Compute hamming weight - number of bits set - in unsigned long
 *
 * Results:
 *      Number of bits set in a value, between 0 and BITS_PER_LONG.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

static inline int
vm_hweight(unsigned long val)  // IN
{
#if BITS_PER_LONG > 32
        /* x86_64 does not have hweight64()... */
        return hweight32(val) + hweight32(val >> 32);
#else
        return hweight32(val);
#endif
}


/*
 *----------------------------------------------------------------------------
 *
 * cpus_weight --
 *
 *      Compute number of bits set in the process affinity mask.
 *
 * Results:
 *      Number of bits set in the mask.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

static inline int
cpus_weight(unsigned long mask)  // IN
{
   /*
    * We mask this with cpu_online_map as by default process is allowed
    * to run even on non-existing processors, and we want to allow such
    * case on UP (where setting affinity is nop, so this mask stays all-ones
    * forever).
    */
   return vm_hweight(mask & cpu_online_map);
}
#endif


/*
 *----------------------------------------------------------------------------
 *
 * os_global_simple_proc_read_node_callback --
 *
 *      This is a generic wrapper for the simple proc read node callback.
 *      Using it enables us to export a much simpler interface than what Linux
 *      requires for proc node read() callbacks.
 *
 * Results:
 *      Return value of the callback.
 *
 * Side effects:
 *      Fires the callback.
 *
 *----------------------------------------------------------------------------
 */

static int
os_global_simple_proc_read_node_callback(char   *buf,
					 char  **start,
					 off_t   offset,
					 int     count,
					 int    *eof,
					 void   *callback_v)
{
   int r;
   os_simple_proc_read_callback callback =
      (os_simple_proc_read_callback) callback_v;

   r = (*callback)(buf);
   *eof = 1;
   return r;
}


/*
 *----------------------------------------------------------------------------
 *
 * os_create_simple_proc_read_node --
 *
 *      This creates a read-only proc node with a very simple interface. The
 *      big assumption made here is that the given callback will generate no
 *      more than one page of data. If it does, the side effects are undefined
 *      (possibly very bad).
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_create_simple_proc_read_node(char *procNodeName,
				os_simple_proc_read_callback func)
{
   create_proc_read_entry(procNodeName,
			  0,
			  NULL,
			  os_global_simple_proc_read_node_callback,
			  (void*)func);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_remove_simple_proc_node --
 *
 *      Wrapper for remove_proc_entry. Remove the specified proc node entry.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_remove_simple_proc_node(char *procNodeName)
{
   remove_proc_entry(procNodeName, NULL);
}


/*----------------------------------------------------------------------------
 *
 * os_add_timer_callback --
 *
 *      Add timer callback that fires ASAP.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_add_timer_callback(os_timer_callback callback,
		      void *param)
{
   globalTimer.expires  = jiffies + 1;
   globalTimer.function = (void (*)(unsigned long))callback;
   globalTimer.data     = (unsigned long)param;
   mod_timer(&globalTimer, globalTimer.expires);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_init_timer --
 *
 *      Wrapper for init_timer.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_init_timer(void)
{
   init_timer(&globalTimer);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_del_timer_sync --
 *
 *      Wrapper for del_timer_sync. Removes our global timer (synchronously).
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_del_timer_sync(void)
{
   del_timer_sync(&globalTimer);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_smp_num_cpus --
 *
 *      Returns the number of (active) CPUs.
 *
 * Results:
 *      Number of CPUs.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

unsigned int CDECL
os_smp_num_cpus(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
   return num_online_cpus();
#else
   return smp_num_cpus;
#endif
}


/*
 *----------------------------------------------------------------------------
 *
 * os_smp_current_cpuid --
 *
 *      Returns the cpu id used by the calling process.
 *
 * Results:
 *      Current CPU id.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

unsigned int CDECL
os_smp_current_cpuid(void)
{
   return smp_processor_id();
}


/*
 *----------------------------------------------------------------------------
 *
 * os_vsprintf --
 *
 *      Wrapper for kernel's vsprintf function.
 *
 * Results:
 *      Return value of vsnprintf with the specified arguments.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

int CDECL
os_vsprintf(char *str, const char *format, ...)
{
   int result;
   va_list args;

   va_start(args, format);
   result = vsprintf(str, format, args);
   va_end(args);

   return result;
}


/*
 *----------------------------------------------------------------------------
 *
 * os_printk --
 *
 *      Wrapper for kernel's printk function.
 *
 * Results:
 *      Return value of printk with the specified arguments.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

int CDECL
os_printk(const char *format, ...)
{
   int result;

   /*
    * XXX: This is a mess.  vmdesched_core.c is built independently from any
    * kernel so it can be shipped as a .o and directly linked with the other
    * files, such as this one, which are built for the target kernel.
    * vmdesched_core.c calls out to this file for any OS-specific calls,
    * however because we have a va_list here we need to call vprintk(), but
    * vprintk() was only exported starting in 2.6.9.  We can supply our own
    * buffer and call vsnprintf() from 2.4.10 and on, but before that, we have
    * nothing to call that will interpret our format string and va_list.  For
    * those kernels we just give up and print the format string; printk() will
    * go looking on the stack for any format specifiers it encounters so the
    * resulting string will likely be junk (hey, it's better than calling
    * vsprintf() and potentially overflowing a buffer like os_vsprintf() does
    * above!).  This whole code structure needs to be rethought (see bug
    * 123595).
    */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 4, 10)
   va_list args;

   va_start(args, format);
# if LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 9)
   result = vprintk(format, args);
# else
   {
      char buf[256];

      vsnprintf(buf, sizeof buf, format, args);
      result = printk(buf);
   }
# endif
   va_end(args);
#else
   result = printk(format);
#endif

   return result;
}


/*
 *----------------------------------------------------------------------------
 *
 * os_init_private_data --
 *
 *      Our OS-dependent device-data structs are stored in an array.  The
 *      OS-agnostic code only ever has a pointer to such structs; this
 *      function initializes such a pointer, given an index into the array.
 *
 *      If the index given is out of bounds, no action is taken.
 *
 * Inputs:
 *      Total number of CPUs
 *
 * Results:
 *      Pointer to initialized thread device structure.
 *
 * Side effects:
 *      Initializes waitqueue and stuff.
 *
 *----------------------------------------------------------------------------
 */

vmdesched_os_data* CDECL
os_init_private_data(int ncpus)
{
   int i;
   spin_lock_init(&vmdeschedOsData.spinlock);

   for (i = 0; i < ncpus; ++i) {
      vmdeschedOsData.wake[i] = 0;
      init_waitqueue_head(&(vmdeschedOsData.waitqueue[i]));
   }
   return &vmdeschedOsData;
}


/*
 *----------------------------------------------------------------------------
 *
 * os_spin_lock --
 * os_spin_unlock --
 *
 *      Lock/unlock the vmdesched device specific lock.
 *      It is just a wrapper for kernel's spin_lock/unlock function.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_spin_lock(vmdesched_os_data *osdata)
{
   spin_lock(&osdata->spinlock);
}

void CDECL
os_spin_unlock(vmdesched_os_data *osdata)
{
   spin_unlock(&osdata->spinlock);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_wake_up_interrruptible --
 *
 *      Wake up the specified thread who waits the device specific events.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

void CDECL
os_wake_up_interruptible(vmdesched_os_data *osdata, int id)
{
   osdata->wake[id] = 1;
   wake_up_interruptible(&osdata->waitqueue[id]);
}


/*
 *----------------------------------------------------------------------------
 *
 * os_wait_event_interruptible --
 *
 *      Puts the specified thread who waits the event to sleep until we signal it.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */
void CDECL
os_wait_event_interruptible(vmdesched_os_data *osdata, int id)
{
   wait_event_interruptible(osdata->waitqueue[id], osdata->wake[id]);
   osdata->wake[id] = 0;
}


/*
 *----------------------------------------------------------------------------
 *
 * os_signal_pending_current --
 *
 *      See if there's a wakeup signal pending for the current thread.
 *
 * Results:
 *      Non-zero value if there is a signal pending to dequeue.
 *
 * Side effects:
 *      None
 *
 *----------------------------------------------------------------------------
 */

int CDECL
os_signal_pending_current(void)
{
   return signal_pending(current);
}


/*
 *----------------------------------------------------------------------------
 *
 * vmdesched_open --
 *
 *      This is the open handler for our vmdesched device.
 *
 * Results:
 *      Zero on success, error code on failure.
 *
 * Side effects:
 *      Increase module count. MOD_INC_USE_COUNT is only defined
 *      in 2.4 kernel version. 2.6 kernel can automatically track
 *      the count with the ownership of the device specified to be
 *      the current module.
 *
 *----------------------------------------------------------------------------
 */

static int
vmdesched_open(struct inode *inode, // IN: underlying inode
               struct file *file)   // IN: user's open file
{
   if (VmDesched_Open() != VMDESCHED_SUCCESS) {
      return -EINVAL;
   }

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
   MOD_INC_USE_COUNT;
#endif

   return 0;
}


/*
 *----------------------------------------------------------------------------
 *
 * vmdesched_release --
 *
 *      This is the release handler for our vmdesched device.
 *
 * Results:
 *      Zero on success, error code on failure.
 *
 * Side effects:
 *      Decrease module count. MOD_DEC_USE_COUNT is only defined
 *      in 2.4 kernel version.
 *
 *----------------------------------------------------------------------------
 */

static int
vmdesched_release(struct inode *inode,
                  struct file *file)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
   MOD_DEC_USE_COUNT;
#endif

   if (VmDesched_Release() != VMDESCHED_SUCCESS) {
      return -EINVAL;
   }

   return 0;
}


/*
 *----------------------------------------------------------------------------
 *
 * vmdesched_ioctl --
 *
 *      This is the ioctl handler for our vmdesched device.
 *      It verifies the ioctl commands and call the cooresponding functions.
 *
 * Results:
 *      Return VMDESCHED_SUCCESS iff successful, otherwise return error code.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

static int
vmdesched_ioctl(struct inode *inode,  // IN: underlying inode
                struct file *file,    // IN: user's open file
                unsigned int cmd,     // IN: command to carry out
                unsigned long arg)    // IN: command arguments (unused)
{
   if (_IOC_TYPE(cmd) != VMDESCHED_IOC_MAGIC) {
      return -ENOTTY;
   }

   if (_IOC_NR(cmd) > VMDESCHED_IOC_MAXNR) {
      return -ENOTTY;
   }

   if (!capable(CAP_SYS_ADMIN)) {
      return -EPERM;
   }

   switch (cmd) {
   case VMDESCHED_IOC_STARTPOLL:
      return VmDesched_StartPoll();
   case VMDESCHED_IOC_STOPPOLL:
      return VmDesched_StopPoll();
   case VMDESCHED_IOC_CONSUME:
      if (cpus_weight(current->cpus_allowed) != 1) {
         return -EINVAL;
      }
      return VmDesched_Consume();
   default:
      return -ENOTTY;
   }
}


#if defined(HAVE_COMPAT_IOCTL) || defined(HAVE_UNLOCKED_IOCTL)
/*
 *----------------------------------------------------------------------------
 *
 * vmdesched_unlocked_ioctl --
 *
 *      This is the ioctl handler for our vmdesched device, used by
 *      32bit apps on 64bit kernel, and/or on kernels which have unlocked_ioctl
 *      method.  Just acquires kernel lock, and calls down to function which
 *      does real work.
 *
 * Results:
 *      Return VMDESCHED_SUCCESS iff successful, otherwise return error code.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

static long
vmdesched_unlocked_ioctl(struct file *file,    // IN: user's open file
                         unsigned int cmd,     // IN: command to carry out
                         unsigned long arg)    // IN: command arguments (unused)
{
   long err;

   lock_kernel();
   err = vmdesched_ioctl(NULL, file, cmd, arg);
   unlock_kernel();
   return err;
}
#endif


/*
 *----------------------------------------------------------------------------
 *
 * os_register_chrdev  --
 * os_unregister_chrdev
 *
 *      Register and unregister vmdesched device as a pseudo char device.
 *      They are wrappers for os dependent register and unregister code.
 *      They are called when insert and remove the module
 *
 * Results:
 *      Return major number or 0 if success, return -1 if fail.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

int CDECL
os_register_chrdev(unsigned int major,
                   const char *name)
{
   return register_chrdev(major, name, &vmdesched_fops);
}

int CDECL
os_unregister_chrdev(unsigned int major,
                     const char *name)
{
   unregister_chrdev(major, name);
   return 0;
}


/*
 *----------------------------------------------------------------------------
 *
 * init_module --
 * cleanup_module --
 *
 *      Our module init and cleanup routines. These need to be in the
 *      OS-dependent code since they're exports, and have to obey the kernel's
 *      calling convention; they are wrappers for our real initialization and
 *      cleanup routines.
 *
 * Results:
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

int
init_module(void)
{
   return VmDesched_Init() == VMDESCHED_SUCCESS ? 0: -EBUSY;
}

void
cleanup_module(void)
{
   VmDesched_Exit();
}
MODULE_AUTHOR("VMware, Inc.");
MODULE_DESCRIPTION("VMware Descheduled Time Accounting Driver.");
MODULE_VERSION(VMDESCHED_DRIVER_VERSION_STRING);
