/* **********************************************************
 * Copyright 2004 VMware, Inc. All rights reserved. -- VMware Confidential
 * **********************************************************/

/*
 * vmdesched_core.h --
 *
 *      Exports some functions need by ioctl handler for vmdesched device
 *      and init/cleanup functions needed to insert/remove vmdesched module
 *      in os.c/os.h.
 */

#ifndef _VMDESCHED_CORE_H_
#define _VMDESCHED_CORE_H_

#ifdef __x86_64__
# define CDECL
#else
# define CDECL __attribute__((cdecl, regparm(0)))
#endif

extern int CDECL VmDesched_Open(void);
extern int CDECL VmDesched_Release(void);
extern int CDECL VmDesched_StartPoll(void);
extern int CDECL VmDesched_StopPoll(void);
extern int CDECL VmDesched_Consume(void);

extern int  CDECL VmDesched_Init(void);
extern void CDECL VmDesched_Exit(void);

#endif
