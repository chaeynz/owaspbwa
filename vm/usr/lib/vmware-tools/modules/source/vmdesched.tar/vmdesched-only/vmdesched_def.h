/* **********************************************************
 * Copyright (C) 2005 VMware, Inc.
 * All Rights Reserved
 * **********************************************************/

/*
 * vmdesched_def.h --
 *
 *      Basic definitions for all VmDesched implementations.
 */

#ifndef _VMDESCHED_DEF_H_
#define _VMDESCHED_DEF_H_


#define VMDESCHED_SHORT_NAME            "vmdesched"
#define VMDESCHED_SERVICE_FRIENDLY_STR  "Descheduled Time Accounting Service"
#define VMDESCHED_SERVICE_FRIENDLY_NAME  VMDESCHED_SHORT_NAME " " VMDESCHED_SERVICE_FRIENDLY_STR

#define VMDESCHED_DRIVER_FRIENDLY_NAME  VMDESCHED_SERVICE_FRIENDLY_NAME " [Driver]"
#define VMDESCHED_DESCRIPTION           "Improves accuracy of timekeeping and " \
                                        "clarifies guest process accounting by " \
                                        "charging time during which the virtual " \
                                        "machine was not running to the vmdesched " \
                                        "service."
#define VMDESCHED_DRIVER_NAME           VMDESCHED_SHORT_NAME "-driver"


#define VMDESCHED_MAX_CPUS              32
#define VMDESCHED_LOG_FILE              VMDESCHED_SHORT_NAME ".log"


/* Error codes for VmDesched Device. Export to the user */
#define VMDESCHED_SUCCESS      (0)
#define VMDESCHED_FAILURE      (-1)
#define VMDESCHED_ERROR_STATE  (1)
#define VMDESCHED_ERROR_BUSY   (2)
#define VMDESCHED_ERROR_QUIT   (3)
#define VMDESCHED_ERROR_SIGNAL (4)


#endif /* _VMDESCHED_DEF_H_ */
